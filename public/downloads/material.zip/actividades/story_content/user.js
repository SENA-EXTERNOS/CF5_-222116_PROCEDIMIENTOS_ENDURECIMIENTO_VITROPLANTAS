function ExecuteScript(strId)
{
  switch (strId)
  {
      case "607ZHM4uQyp":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

